
const greenJobKeywords = [
    'green', 'sustainability', 'renewable', 'solar', 'environmental',
    'climate', 'carbon', 'eco', 'energy', 'recycle', 'biodiversity', 'conservation', 'hijau', 
    'petani', 'nelayan', 'energi terbarukan', 'energi', 'tenaga matahari'
];

let isModelLoaded = false;
let model;
let word2index;

const maxlen = 241;

function padSequence(sequences, maxLen, padding='post', truncating = "post", pad_value = 0){
    return sequences.map(seq => {
        if (seq.length > maxLen) {
            if (truncating === 'pre'){
                seq.splice(0, seq.length - maxLen);
            } else {
                seq.splice(maxLen, seq.length - maxLen);
            }
        }
        if (seq.length < maxLen) {
            const pad = [];
            for (let i = 0; i < maxLen - seq.length; i++){
                pad.push(pad_value);
            }
            seq = (padding === 'pre') ? pad.concat(seq) : seq.concat(pad);
        }
        return seq;
    });
}

async function predict(inputText) {
    const sequence = inputText.map(word => {
        let indexed = word2index[word.toLowerCase()];
        return indexed === undefined ? 1 : indexed;
    });

    const paddedSequence = padSequence([sequence], maxlen);
    const inputTensor = tf.tensor2d(paddedSequence, [1, maxlen]);

    const containsKeyword = inputText.some(word =>
        greenJobKeywords.includes(word.toLowerCase())
    );

    const result = await model.executeAsync({ 'inputs': inputTensor });
    let score = (await result.data())[0];

    if (containsKeyword) {
        score = Math.min(score + 0.75, 1);
    }

    document.getElementById("result").innerText = `Hasil prediksi: ${score.toFixed(2)}`;
    return score;
}

async function onClick() {
    if (!isModelLoaded) {
        alert('Model not loaded yet');
        return;
    }

    if (getInput() === '') {
        alert("Review Can't be Null");
        document.getElementById('input').focus();
        return;
    }

    const inputText = getInput().trim().toLowerCase().split(" ");
    let score = await predict(inputText);

    if (score > 0.5) {
        alert('Benar! itu adalah Greenjobs \n' + score);
    } else {
        alert('Maaf! sepertinya itu bukan Greenjobs \n' + score);
    }
}

function getInput(){
    const reviewText = document.getElementById('input');
    return reviewText.value;
}

window.addEventListener('load', async () => {
    model = await tf.loadGraphModel('tfjs_model/model.json');
    const word_indexjson = await fetch('word_index.json');
    word2index = await word_indexjson.json();
    isModelLoaded = true;
    console.log("Model loaded successfully.");
});

document.getElementById('cek-button').addEventListener('click', onClick);
