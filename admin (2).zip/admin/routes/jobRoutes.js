            const express = require('express');
            const router = express.Router();
            const Job = require('../models/Job')

            // Create job
            router.post('/', async (req, res) => {
                const job = new Job(req.body);
                try {
                    await job.save();
                    res.status(201).send(job);
                } catch (error) {
                    res.status(400).send(error);
                }
            });

            // Read all jobs
            router.get('/', async (req, res) => {
                try {
                    const jobs = await Job.find();
                    res.send(jobs);
                } catch (error) {
                    res.status(500).send(error);
                }
            });

            // Update job
            router.put('/:id', async (req, res) => {
                try {
                    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
                    res.send(job);
                } catch (error) {
                    res.status(400).send(error);
                }
            });

            // Delete job
            router.delete('/:id', async (req, res) => {
                try {
                    await Job.findByIdAndDelete(req.params.id);
                    res.status(204).send();
                } catch (error) {
                    res.status(500).send(error);
                }
            });

            // Update job (duplicate, can be removed)
            router.put('/:id', async (req, res) => {
                try {
                    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
                    res.send(job);
                } catch (error) {
                    res.status(400).send(error);
                }
            });
            

            module.exports = router;