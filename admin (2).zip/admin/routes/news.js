const express = require('express');
const router = express.Router();
const News = require('../models/news');

// Create news
router.post('/', async (req, res) => {
    const news = new News(req.body);
    try {
        await news.save();
        res.status(201).send(news);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Read all news
router.get('/', async (req, res) => {
    try {
        const news = await News.find();
        res.send(news);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Update news
router.put('/:id', async (req, res) => {
    try {
        const news = await News.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.send(news);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Delete news
router.delete('/:id', async (req, res) => {
    try {
        await News.findByIdAndDelete(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(500).send(error);
    }
});

// Update news
router.put('/:id', async (req, res) => {
    try {
        const news = await News.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.send(news);
    } catch (error) {
        res.status(400).send(error);
    }
});

module.exports = router;