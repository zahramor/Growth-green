const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    title: { type: String, required: true },
    logo: { type: String, required: true },
    location: { type: String, required: true },
    minExperience: { type: String, required: true },
    date: { type: Date, required: true },
    category: { type: String, enum: [  
        'sales administrator', 
            'HRD', 
            'Marketing', 
            'Building-Manager', 
            'Fundraising-Manager', 
            'Security-Officer', 
            'ESG-Manager', 
            'Environment-Landscaping-Support', 
            'Landscaping-Manager-(M/W)-Club-Med Resort-Indonesia-or-overseas', 
            'Operator-WWTP-&-Limbah-B3', 
            'Manajer-Pengembangan-Bisnis-(Energi-Terbarukan)'], required: true },
    link: { type: String, required: true } 
});

const Job = mongoose.model('Job', jobSchema);
module.exports = Job;
